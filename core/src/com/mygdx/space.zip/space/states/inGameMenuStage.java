package com.mygdx.space.states;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class inGameMenuStage extends State
{

    protected inGameMenuStage(GameStateManager gsm) {
        super(gsm);
    }

    @Override
    protected void handleInput() {

    }

    @Override
    public void update(float dt)
    {
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb)
    {

    }

    @Override
    public void dispose()
    {

    }
}
