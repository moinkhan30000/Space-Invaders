package com.mygdx.space.weapons;

public class secondaryWeapon {
}
